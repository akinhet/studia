import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.*;

public class Test {
	static String generateOutput(int n)
	{
		List<String> output = new ArrayList<String>();

		try {
			for (int i = 0; i <= n; i++) {
				output.add(new String(""));
				WierszTrojkataPascala wiersz = new WierszTrojkataPascala(i);
				wiersz.GenerateRow();
				for (int j = 0; j <= i; j++) {
					output.set(i, output.get(i) + wiersz.GetElement(j) + " ");
				}
			}
		} catch (IntegerOutOfBounds e) {
			return "Invalid input";
		}

		String ret = "";

		for (int i = 0; i <= n; i++) {
			int diff = (output.get(n).length() - output.get(i).length()) / 2;
			ret += " ".repeat(diff) + output.get(i) + "\n";
		}

		return ret;
	}


    public static void main(String[] args)
    {
        JFrame frame = new JFrame("Trójkąt Pascala");
		JPanel panel = new JPanel();
		GridBagConstraints gbc = new GridBagConstraints();
		GridBagLayout gridbag = new GridBagLayout();
		panel.setLayout(gridbag);

		Scrollbar slider = new Scrollbar(Scrollbar.HORIZONTAL, 0, 1, 0, 101);
        Label sliderLabel = new Label("Value: 0");
		Button button = new Button("Generate");
		Button darkmode = new Button("Dark");
		TextArea result = new TextArea();

		slider.addAdjustmentListener(new AdjustmentListener() {
			public void adjustmentValueChanged(AdjustmentEvent e) {
				sliderLabel.setText("Value: " + slider.getValue());
			}
		});

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result.setText(generateOutput(slider.getValue()));
			}
		});

		darkmode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (darkmode.getLabel() == "Dark") {
					darkmode.setLabel("Light");
					panel.setBackground(Color.BLACK);
					panel.setForeground(Color.GREEN);
					result.setBackground(Color.BLACK);
					result.setForeground(Color.GREEN);
				} else {
					darkmode.setLabel("Dark");
					panel.setBackground(Color.WHITE);
					panel.setForeground(Color.BLACK);
					result.setBackground(Color.WHITE);
					result.setForeground(Color.BLACK);
				}
			}
		});

		panel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
		panel.setLayout(new GridBagLayout());
		panel.setBackground(Color.WHITE);
		panel.setForeground(Color.BLACK);

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0.5;
		gbc.weighty = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gridbag.setConstraints(slider, gbc);
		panel.add(slider);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 0.15;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gridbag.setConstraints(sliderLabel, gbc);
		panel.add(sliderLabel);

		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.weightx = 0.25;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gridbag.setConstraints(button, gbc);
		panel.add(button);

		gbc.gridx = 3;
		gbc.gridy = 0;
		gbc.weightx = 0.05;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gridbag.setConstraints(darkmode, gbc);
		panel.add(darkmode);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 4;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.anchor = GridBagConstraints.CENTER;
		result.setEditable(false);
		result.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 10));
		result.setBackground(Color.WHITE);
		result.setForeground(Color.BLACK);
		gridbag.setConstraints(result, gbc);
		panel.add(result);

		frame.add(panel);
        frame.setSize(700, 700);
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e)
            {
				frame.dispose();
            }
        });
    }
}
