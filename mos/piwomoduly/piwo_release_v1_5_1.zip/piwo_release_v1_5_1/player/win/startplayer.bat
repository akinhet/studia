set QML_IMPORT_PATH=%CD%\qml
set QML2_IMPORT_PATH=%CD%\qml
set QT_QPA_PLATFORM_PLUGIN_PATH=%CD%\plugins\platforms
set QT_PLUGIN_PATH=%CD%\plugins

::set QT_DEBUG_PLUGINS=1

Player.exe
